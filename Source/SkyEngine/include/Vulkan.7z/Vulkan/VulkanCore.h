#pragma once

#include <stdio.h>        
#include <stdlib.h>        

#include "VulkanUtils.hpp"

//#define IMGUI_UNLIMITED_FRAME_RATE
#ifdef _DEBUG
#define IMGUI_VULKAN_DEBUG_REPORT
#endif


const std::vector<const char*> deviceExtensions = {
    VK_KHR_SWAPCHAIN_EXTENSION_NAME
};


#ifdef NDEBUG
const bool enableValidationLayers = false;
#else
const bool enableValidationLayers = true;
#endif


struct VulkanContext
{
	VkAllocationCallbacks*   Allocator = NULL;
	VkInstance               Instance = VK_NULL_HANDLE;
	VkPhysicalDevice         PhysicalDevice = VK_NULL_HANDLE;
	VkDevice                 Device = VK_NULL_HANDLE;
	uint32_t                 QueueFamily = (uint32_t)-1;
	VkDebugReportCallbackEXT DebugReport = VK_NULL_HANDLE;
    VkDebugUtilsMessengerEXT DebugMessenger;
	VkPipelineCache          PipelineCache = VK_NULL_HANDLE;
	VkDescriptorPool         DescriptorPool = VK_NULL_HANDLE;
	VkSurfaceKHR			 Surface;
	uint32_t                 MinImageCount = 2;
	uint32_t                 ImageCount;
    VkSwapchainKHR           SwapChain;
	VkRenderPass			 RenderPass;
	VkCommandPool			 CommandPool;
	std::vector<VkCommandBuffer> CommandBuffers;
	VkCommandBuffer* CurCommandBuffer;
	VkQueue GraphicsQueue;
	VkQueue PresentQueue;

	bool                     SwapChainRebuild = false;
};

static void check_vk_result(VkResult err)
{
	if (err == 0)
		return;
	fprintf(stderr, "[vulkan] Error: VkResult = %d\n", err);
	if (err < 0)
		abort();
}

#ifdef IMGUI_VULKAN_DEBUG_REPORT
static VKAPI_ATTR VkBool32 VKAPI_CALL debug_report(VkDebugReportFlagsEXT flags, VkDebugReportObjectTypeEXT objectType, uint64_t object, size_t location, int32_t messageCode, const char* pLayerPrefix, const char* pMessage, void* pUserData)
{
	(void)flags; (void)object; (void)location; (void)messageCode; (void)pUserData; (void)pLayerPrefix; // Unused arguments
	fprintf(stderr, "[vulkan] Debug report from ObjectType: %i\nMessage: %s\n\n", objectType, pMessage);
	return VK_FALSE;
}
#endif // IMGUI_VULKAN_DEBUG_REPORT
